## Thanks

Thank you everyone for your contributions and feedback. They have helped make Textadept the
amazing editor that it is today.

### Code and Documentation Contributors

- Ahed Eid
- Alex Bepple
- Ana Balan
- Anton Verbitski
- Benjamin Barenblat
- Bill Meahan
- Brian Schott
- Callum Wilson
- Carl Sturtivant
- Chris Emerson
- Christof Böckler
- Daniel Wutke
- Franck Guadagnini
- Gabriel Dubatti
- Georger Araújo
- Gilles Grégoire
- Giovanni Salmeri
- Heck Fy
- Ivan Baidakou
- Jay Gould
- Jeff Stone
- John Benediktsson
- Lance Larsen
- M Rawash
- Manuel Montenegro
- Markus F.X.J. Oberhume
- Martin Morawetz
- Michael T. Richter
- Neil Hodgson
- Niklas Wallén
- Nils Nordman
- Patrick McMorris
- Pedro Andres Aranda Gutierrez
- Piotr Orzechowski
- Richard Philips
- Robert Gieseke
- Russell Dickenson
- Ryan Pusztai
- Scott Weisman
- Steve Donovan
- Tymur Gubayev
- Vais Salikhov
- Vladimir Lomov

If I have left off your name, please contact me (see README.md). I am very sorry about that.
