-- Copyright 2006-2024 Mitchell. See LICENSE.
-- Null LPeg lexer.

return require('lexer').new('null')
